/*
 * creates an enumerated data type for genre
 *
 * Alexander Jessop
 */

public enum Genre
{
  MYSTERY, FANTASY, HUMOR;
}