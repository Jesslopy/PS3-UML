/*
 * --Alexander Jessop--
 */

 public enum Genre {
    MYSTERY,
    THRILLER,
    ROMANCE,
    SCIENCE_FICTION,
    FANTASY,
    HORROR,
    ADVENTURE,
    HUMOR,
}
